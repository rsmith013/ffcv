from typing import Sequence, TYPE_CHECKING

BATCHES_TYPE = Sequence[Sequence[int]]